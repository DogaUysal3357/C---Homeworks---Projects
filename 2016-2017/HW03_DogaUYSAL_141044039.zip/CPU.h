﻿/* 
 * File:   CPU.h
 * Author: Doğa UYSAL   141044039
 *
 * Created on 21 Ekim 2016 Cuma, 04:17
 */

#ifndef CPU_H
#define	CPU_H

#include <string>
#include <iostream>
#include <cmath> // for pow func
using namespace std;


const int REGISTER_SIZE = 5;

class CPU {
public:
    CPU();
    CPU(int opt);

    //Okunan lineların teker teker execute eidlerek gerekli instructionların cagirildigi func
    int Execute(string line);

    // Programin halt edilip edilmedigini return eden func
    bool Halted();

    // Register degerlerini ekrana basan func
    void Print();

    // Programi halt eden func
    void Halt();

    // Istenen registeri return eden func
    int getRegisterVal(int registerNum);

    // Istenen registerin degistirilmesini saglayan func
    void setRegisterVal(int registerNum, int registerVal);


    int getPC();
    void setPC(int _pc);

    CPU(const CPU& orig);
    virtual ~CPU();
private:

    // Register arrayi
    int registers[REGISTER_SIZE];
    // Okunacak line bilgisini tutan ProgramCounter
    int PC;
    int option;
    bool halted;

    // Line icindeki instruction stringi
    string instruction;
    // Line icindeki 1. command
    string command1;
    // Line icindeki 2.command
    string command2;

    //Parse elemanlarının içlerini boşaltıp yeniden kullanıma hazır hale getirir.
    void ResetParseElems();
    void setHalt(bool _h);
    // Move Instruction
    void Move();
    // Add Instruction
    void Add();
    // Substract Instruction
    void Substract();
    // Jump Instruction.  
    // opt -> 1 , Register check, jump
    // opt -> 0,  constant jump
    int Jump(int opt);
    // Stringleri int'e ceviren func
    int HandMadeAtoi(string comm);
    // Satirlari parslayarak instruction funclarini cagfiran func
    int FillUpParams(string line);

};

#endif	/* CPU_H */

