/*
* File:   main.cpp
* Author: Doğa UYSAL   141044039
*
* Created on 21 Ekim 2016 Cuma, 03:37
*/

#include "CPU.h"
#include "CPUProgram.h"

using namespace std;

int main(int argc, char** argv) {

	int option = 0;
	int newLineAdress = 0;


	// Program gerekli argumanalrla çalıştırılmışmı diye kontrol edilir.
	if (argc != 3) {
		cout << "Usage : programName filename option  " << endl;
		return 1;
	}

	// option dogru girilmis mi diye kontrol yapılır.
	if (argv[2][0] == '1') {
		option = 1;
	}
	else if (argv[2][0] == '0') {
		option = 0;
	}
	else {
		cout << "Option can only be 0 or 1" << endl;
		return 1;
	}

	CPU myCPU(option);
	CPUProgram myProg(argv[1]);

	// Program halt edilene kadar calisir.
	while (!myCPU.Halted()) {

		newLineAdress = myCPU.Execute(myProg.getLine(myCPU.getPC()));
		if (newLineAdress == -1) { // -1 return edilirse JMP yakalanmamis demektir. Sonraki satira gecilir.
			myCPU.setPC(myCPU.getPC() + 1);
		}
		else if (newLineAdress == -2) { // -2 return edildiyse program halt edilmesi gerekmektedir demektedir. 
			myCPU.Halt();
		}
		else { // Eger pozitif bir deger return edilmisse JMP instrucitonı gelmis demektir. PC gerekli sekilde update edilir.    
			myCPU.setPC(newLineAdress);
		}
	}

	return 0;
}

