﻿/* 
 * File:   CPUProgram.h
 * Author: Doğa UYSAL   141044039
 *
 * Created on 21 Ekim 2016 Cuma, 03:55
 */

#ifndef CPUPROGRAM_H
#define	CPUPROGRAM_H


#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h> // exit, exit_failure
using namespace std;

const int MAX_LINE_SIZE = 200;

class CPUProgram {
public:
    CPUProgram(char* fileName);
    
    // Verilen dosya ismiyle dosyayı baştan sonra kadar okur. Hatali bir giriş veya 200 satirdan uzunsa exit ile programdan çıkış yapılır.
    void ReadFile(char* fileName);
    // Input olarak PC alinir ve istenen satir numarasindaki string return edilir.
    string getLine(int lineNum);
    
    int getSize();
    CPUProgram(const CPUProgram& orig);
    virtual ~CPUProgram();
private:
    int size;
    string lines[MAX_LINE_SIZE];

    void IncrementSize();
};

#endif	/* CPUPROGRAM_H */

