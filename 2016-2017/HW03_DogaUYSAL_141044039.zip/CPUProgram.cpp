/*
* File:   CPUProgram.cpp
* Author: Doğa UYSAL   141044039
*
* Created on 21 Ekim 2016 Cuma, 03:55
*/

#include "CPUProgram.h"

CPUProgram::CPUProgram(char* fileName) {
	size = 0;
	ReadFile(fileName);
}

void CPUProgram::ReadFile(char* fileName) {
	ifstream inFile;

	inFile.open(fileName);

	if (inFile.is_open()) {// dosya acinarak okuma yapilir.
		while (getline(inFile, lines[size])) {
			IncrementSize();
			if (size > MAX_LINE_SIZE + 1) {
				cout << " Max File Size is 200" << endl;
				exit(EXIT_FAILURE);
			}
		}
	}
	else {
		cout << "Could not open the file named -> " << fileName << endl;
		exit(EXIT_FAILURE);
	}

	inFile.close();
}

string CPUProgram::getLine(int lineNum) {
	return lines[lineNum - 1];
}

void CPUProgram::IncrementSize() {
	size++;
}

CPUProgram::CPUProgram(const CPUProgram& orig) {
}

CPUProgram::~CPUProgram() {
}

