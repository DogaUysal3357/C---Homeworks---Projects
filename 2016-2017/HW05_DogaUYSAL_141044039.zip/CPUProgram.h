/* 
 * File:   CPUProgram.h
 * Author: Doğa
 *
 * Created on 11 Kasım 2016 Cuma, 16:40
 */

#ifndef CPUPROGRAM_H
#define	CPUPROGRAM_H


#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h> // exit, exit_failure
#include <vector>
using namespace std;

class CPUProgram {
public:
    CPUProgram();
    CPUProgram(int option);
    // Verilen dosya ismiyle dosyayı baştan sonra kadar okur. Hatali bir giriş veya 200 satirdan uzunsa exit ile programdan çıkış yapılır.
    void ReadFile(const char* fileName);
    // Input olarak PC alinir ve istenen satir numarasindaki string return edilir.
    string getLine(int lineNum);

    const string operator[](int index);

    CPUProgram operator +(const string line);
    CPUProgram operator +(CPUProgram progToAdd);
    CPUProgram operator =( CPUProgram& rightSide);
    void operator +=(string lineToAdd);
    bool operator ==( CPUProgram progToCompare) ;
    bool operator !=( CPUProgram progToCompare) ;
    bool operator <( CPUProgram progToCompare) ;
    bool operator <=( CPUProgram progToCompare) ;
    bool operator >( CPUProgram progToCompare) ;
    bool operator >=( CPUProgram progToCompare) ;
    CPUProgram operator ()( int firstIndex,  int secondIndex);
    friend ostream& operator <<(ostream& outputStream,  const CPUProgram& prog);
    CPUProgram& operator --(); //Prefix
    CPUProgram operator --(int i); //Postfix

    int getSize()const;
	int size()const;
    CPUProgram(CPUProgram& orig);
private:
    vector<string> lines;
    int option;
    void AddLine(string newLine);
};

#endif	/* CPUPROGRAM_H */

