/* 
 * File:   CPUProgram.cpp
 * Author: Doğa
 * 
 * Created on 11 Kasım 2016 Cuma, 16:40
 */
#include "CPUProgram.h"

CPUProgram::CPUProgram() {
    option = 0;
}

CPUProgram::CPUProgram(int opt) {
    option = option;
}

CPUProgram::CPUProgram(CPUProgram& orig) {

    if (getSize() != orig.getSize()) {
        lines.resize(orig.getSize());
    }

    for (int i = 0; i < getSize(); ++i) {
        lines[i] = orig.lines[i];
    }
}

const string CPUProgram::operator[](int index) {
    if (index >= lines.size()) {
        cout << "Index -> " << index << " is out of range." << endl;
        exit(1);
    }
    return getLine(index);
	
}

CPUProgram CPUProgram::operator=(CPUProgram& rightSide) {
    if (getSize() != rightSide.getSize()) {
        lines.resize(rightSide.getSize());
    }

    for (int i = 0; i < getSize(); ++i) {
        lines[i] = rightSide.lines[i];
    }
    return (*this);
}

CPUProgram CPUProgram::operator()( int firstIndex, int secondIndex) {
    int fIndex = firstIndex;
    int sIndex = secondIndex;

    CPUProgram newProg;

	if (fIndex < 0 || fIndex >= sIndex || sIndex >= lines.size()){
		cout << " Invalid Index ->  First : " << fIndex << " Second : " << sIndex << endl;
		exit(1);
	}

    for (int i = fIndex; i <= sIndex; ++i) {
        newProg.AddLine(getLine(i));
    }

    return newProg;

}

CPUProgram CPUProgram::operator+( string line)  {
    CPUProgram newProgram(*this);
    newProgram += line;
    return newProgram;
}

CPUProgram CPUProgram::operator+(CPUProgram progToAdd) {
    CPUProgram newProg(*this);

    for (int i = 0; i < progToAdd.getSize(); ++i) {
        (newProg.lines).push_back(progToAdd[i]);
    }

    return newProg;
}

void CPUProgram::operator+=(string lineToAdd) {
    lines.push_back(lineToAdd);
}

bool CPUProgram::operator<( CPUProgram progToCompare)  {
    return getSize() < progToCompare.getSize();
}

bool CPUProgram::operator<=( CPUProgram progToCompare)  {
    return getSize() <= progToCompare.getSize();
}

bool CPUProgram::operator==( CPUProgram progToCompare)  {
    return getSize() == progToCompare.getSize();
}

bool CPUProgram::operator!=( CPUProgram progToCompare)  {
    return getSize() != progToCompare.getSize();
}

bool CPUProgram::operator>( CPUProgram progToCompare)  {
    return getSize() > progToCompare.getSize();
}

bool CPUProgram::operator>=( CPUProgram progToCompare)  {
    return getSize() >= progToCompare.getSize();
}

ostream& operator <<(ostream& outputStream,  const CPUProgram& prog) {
    outputStream << " File Includes : " << endl;
    for (int i = 0; i < prog.getSize(); ++i) {
        outputStream << prog.lines[i] << endl;
    }
    outputStream << endl;
    return outputStream;
}

CPUProgram& CPUProgram::operator--() { //Prefix
    lines.pop_back();
    return (*this);
}

CPUProgram CPUProgram::operator--(int i) { // postfix
    CPUProgram progToReturn(*this);
    lines.pop_back();
    return progToReturn;
}

void CPUProgram::ReadFile(const char* fileName) {
    ifstream inFile;
    string lineStorage;
    inFile.open(fileName);

    if (inFile.is_open()) {// dosya acinarak okuma yapilir.
        while (getline(inFile, lineStorage)) {
            lines.push_back(lineStorage);
        }
    } else {
        cout << "Could not open the file named -> " << fileName << endl;
        exit(EXIT_FAILURE);
    }

    inFile.close();
}

string CPUProgram::getLine(int lineNum) {
    return lines[lineNum];
}

void CPUProgram::AddLine(string newLine){
	lines.push_back(newLine);
}

int CPUProgram::size() const{
	return getSize();
}

int CPUProgram::getSize() const{
	return lines.size();
}

