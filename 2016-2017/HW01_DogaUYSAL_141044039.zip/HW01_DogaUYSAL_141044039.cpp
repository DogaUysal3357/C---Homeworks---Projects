/* 
 * File:   main.cpp
 * Author: Doğa Uysal 141044039
 *
 * Created on 01 Ekim 2016 Cumartesi, 14:43
 */
 
#include <iostream>
#include <fstream>
#include <string.h>
#include <cmath> // HandMadeAtoi icinde pow alabilmek icin kullanıldı
 
using namespace std;
 
/* Okunan line teker teker instruction ve command'ler olmak uzere parcalanir
 * Parcalanma islemi yapildiktan sonra instructionlar gerekli sekilde gerceklestirilir.
 * Inputlarda hata varsa gerekli degerler donulerek Halt edilir.*/
int Execute(string line, int *regValue, int option);
//2 adet string ve register array'ini alarak, constant mi yoksa register mi olduklari kontrol edilerek gerekli atama islemi yapılır.
void Move(string comm1, string comm2, int* regValue);
//2 adet command stringi ve register arrayi alinarak gerekli toplama islemleri yapilir ve register'a atanir.
void Add(string comm1, string comm2, int* regValue);
//2 adet command string'i ve register arrayi alinir. Constant ve register ayristirmalari yapildiktan sonra çıkarma islemi yapılarak gerekli register'a atanir
void Substract(string comm1, string comm2, int* regValue);
// 2 adet string ve register arrayi alinir. Eger istenen register 0 ise verilen adress return edilir.
// Register 0 degilse -1 donulerek bir sonraki line'a gecilmesi isaret edilir.
int Jump(string adress);
// Verilen constant deger int olarak return edilerek, o line'a gecis yapilmasi gerektigi belirtilir.
int Jump(string reg, string adress, int* regValue);
//Command stringi ve register arrayi alinir. Istenen degerler ekrana basilir.
void Print(string comm, int* regValue);
// Programin sonlandigi belirtilerek, tum registerlar iclerindeki degerler ile ekrana basilir.
void Halt(int* regValue);

// stringleri int'e çeviren func
int HandMadeAtoi(string strLine);
/* Okunan line gerekli sekilde instruction ve commandler olarak ayristirilir.
 * "Instruction command1, command2" 
 * "Instruction command " formatinda olmayan tüm line'lar hatalı olarak varsayılır. */
int FillUpParams(string line, string& instruction, string& command1, string& command2);
 
const int MAX_LINE = 100;
const int REGISTER_SIZE = 5;
 
int main(int argc, char** argv) {
 
    int regValue[REGISTER_SIZE] = {0, 0, 0, 0, 0};
    string lines[MAX_LINE];
    int option = 0;
    int lineAdress = 0;
    int newLineAdress = 0;
    bool halted = false;
    ifstream inFile;
    int i = 0;
 
	//Arguman kontrolu
    if (argc != 3) {
        cout << "Usage : programName filename option  " << endl;
        return 1;
    }
 
	// Option argumanin dogru girilip girilmediginin kontrolu
    if (argv[2][0] == '1') {
        option = 1;
    } else if (argv[2][0] == '0') {
        option = 0;
    } else {
        cout << "Option can only be 0 or 1" << endl;
        return 1;
    }
 
    inFile.open(argv[1]);
 
	//Dosya eger dogru yazilmissa okunmaya baslanir. Eger istenen dosya bulunamazsa bilgilendirici output ekrana basilir ve programdan cikis yapilir.
    if (inFile.is_open()) {
        while (getline(inFile, lines[i])) {
            ++i;
        }
    } else {
        cout << "Could not open the file named -> " << argv[1] << endl;
        return 1;
    }
 
	// Program halt edilene kadar dongu icinde calisir.
	// Okunann her line execute fonksyonu icine, register bilgileri ve option ile birlikte gonderilir.
	// Execute'un return ettigi degere gore hangi line gecis yapilacagi belirlenir.
	// return -2 -> Program Halt edilecektir.
	// return -1 -> Bir sonraki line'a gecilecek
	// Diger tum degeler -> Donulen degerin line'ına gecis yapilir.
    while (!halted) {
        newLineAdress = Execute(lines[lineAdress], regValue, option);
        if (newLineAdress == -1) {
            ++lineAdress;
        } else if (newLineAdress == -2) {
            Halt(regValue);
            halted = true;
        } else {
            lineAdress = newLineAdress - 1;
        }
    }
 
	//Dosya kapanir
    inFile.close();
 
    return 0;
}
 
// Okunan line teker teker instruction ve command'ler olmak uzere parcalanir
// Parcalanma islemi yapildiktan sonra instructionlar gerekli sekilde gerceklestirilir.
// Inputlarda hata varsa gerekli degerler donulerek Halt edilir.
 // Return edilen integer deger, bu execute isleminden sonra hangi line'a gecilecegini belirtir.
int Execute(string line, int *regValue, int option) {
 
    string instruction = "",
            command1 = "",
            command2 = "";
    int read = 0; // Alinan line parcalandiktan sonra icinden cikan string sayisi
 
 
    read = FillUpParams(line, instruction, command1, command2);
	//Yeterli sayida string okunup okunmadigiin kontrolu
    if ((read <= 1) && !(instruction == "HLT" || instruction == "hLT" || instruction == "hlT" || instruction == "hlt" || instruction == "hLt" || instruction == "Hlt" || instruction == "hlT" || instruction == "hLt")) {
        cout << "Invalid Input : " << line << endl
                << "Input Format : 'Insturction Command1, Command2' or 'Instruction Command' " << endl;
        return -2;
    }
 
    if (instruction == "MOV" || instruction == "mOV" || instruction == "moV" || instruction == "mov"
            || instruction == "MoV" || instruction == "Mov" || instruction == "moV" || instruction == "mOv") {
        if (read != 3) { // Yeterli sayida input oldugunun kontrolu
            return -2;
        } else
            Move(command1, command2, regValue);
    } else if (instruction == "ADD" || instruction == "aDD" || instruction == "adD" || instruction == "add"
            || instruction == "AdD" || instruction == "Add" || instruction == "adD" || instruction == "aDd") {
        if (read != 3) { // Yeterli sayida input oldugunun kontrolu
            return -2;
        } else
            Add(command1, command2, regValue);
    } else if (instruction == "SUB" || instruction == "sUB" || instruction == "suB" || instruction == "sub"
            || instruction == "SuB" || instruction == "Sub" || instruction == "suB" || instruction == "sUb") {
        if (read != 3) { // Yeterli sayida input oldugunun kontrolu
            return -2;
        } else
            Substract(command1, command2, regValue);
    } else if (instruction == "JMP" || instruction == "jMP" || instruction == "jmP" || instruction == "jmp"
            || instruction == "JmP" || instruction == "Jmp" || instruction == "jmP" || instruction == "jMp") {
        if (read == 2) { 
            return Jump(command1);
        } else if (read == 3) {
            return Jump(command1, command2, regValue);
        } else
            return -2;
    } else if (instruction == "PRN" || instruction == "pRN" || instruction == "prN" || instruction == "prn"
            || instruction == "PrN" || instruction == "Prn" || instruction == "prN" || instruction == "pRn") {
        if (read != 2) { // Yeterli sayida input oldugunun kontrolu
            return -2;
        } else
            Print(command1, regValue);
    } else if (instruction == "HLT" || instruction == "hLT" || instruction == "hlT" || instruction == "hlt"
            || instruction == "hLt" || instruction == "Hlt" || instruction == "hlT" || instruction == "hLt") {
        return -2;
    } else {  // Gecersin Instriction girisi
        cout << "Invalid Input : " << line << endl
                << "Input Format : 'Insturction Command1, Command2' or 'Instruction Command' " << endl;
        return -2;
    }
 
    if (option == 1) {
        cout << "Executed Command -> " << line << endl
                << "Registers :" << endl;
        for (int i = 0; i < REGISTER_SIZE; ++i) {
            cout << 'R' << (i + 1) << " : " << regValue[i] << endl;
        }
    }
 
    return -1;
}
 
//2 adet string ve register array'ini alarak, constant mi yoksa register mi olduklari kontrol edilerek gerekli atama islemi yapılır.
void Move(string comm1, string comm2, int *regValue) {
    int register1 = 0;
    int register2 = 0;
 
    register1 = (int) (comm1[1] - '1');
 
    if (comm2[0] == 'R') { // comm2 is a register
        register2 = (int) (comm2[1] - '1');
        regValue[register2] = regValue[register1];
    } else {
        regValue[register1] = HandMadeAtoi(comm2);
    }
}
 
//2 adet command stringi ve register arrayi alinarak gerekli toplama islemleri yapilir ve register'a atanir.
void Add(string comm1, string comm2, int *regValue) { 
    int register1 = 0;
    int register2 = 0;
 
    register1 = (int) (comm1[1] - '1');
 
    if (comm2[0] == 'R') { // comm2 is a register
        register2 = (int) (comm2[1] - '1');
        regValue[register1] += regValue[register2];
    } else {
        regValue[register1] += HandMadeAtoi(comm2);
    }
}
 
//2 adet command string'i ve register arrayi alinir. Constant ve register ayristirmalari yapildiktan sonra çıkarma islemi yapılarak gerekli register'a atanir
void Substract(string comm1, string comm2, int *regValue) {
    int register1 = 0;
    int register2 = 0;
 
    register1 = (int) (comm1[1] - '1');
 
    if (comm2[0] == 'R') { // comm2 is a register
        register2 = (int) comm2[1];
        regValue[register1] -= regValue[register2];
    } else {
        regValue[register1] -= HandMadeAtoi(comm2);
    }
}
 
// 2 adet string ve register arrayi alinir. Eger istenen register 0 ise verilen adress return edilir.
// Register 0 degilse -1 donulerek bir sonraki line'a gecilmesi isaret edilir.
int Jump(string reg, string adress, int *regValue) {
    int newAdress = -1;
    int register1 = 0;
 
    register1 = (int) (reg[1] - '1');
    if (regValue[register1] == 0) {
        newAdress = HandMadeAtoi(adress);
    }
 
    return newAdress;
}
 
// Verilen constant deger int olarak return edilerek, o line'a gecis yapilmasi gerektigi belirtilir.
int Jump(string adress) {
    return HandMadeAtoi(adress);
}
 
//Command stringi ve register arrayi alinir. Istenen degerler ekrana basilir.
void Print(string comm, int *regValue) {
    int reg = 0;
 
    if (comm[0] != 'R') { // comm is a constant
        cout << comm << endl;
    } else {
        reg = (int) (comm[1] - '1');
        cout << regValue[reg] << endl;
    }
}
 
// Programin sonlandigi belirtilerek, tum registerlar iclerindeki degerler ile ekrana basilir.
void Halt(int* regValue) {
    cout << "Program halted. Registers : " << endl;
    for (int i = 0; i < REGISTER_SIZE; i++) {
        cout << 'R' << (i + 1) << " : " << regValue[i] << endl;
    }
}
 
/* Okunan line gerekli sekilde instruction ve commandler olarak ayristirilir.
 * "Instruction command1, command2" 
 * "Instruction command " formatinda olmayan tüm line'lar hatalı olarak varsayılır.*/
int FillUpParams(string line, string &instruction, string &command1, string &command2) {
    int read = 0;
    int i = 0;
 
 
    // Baslangictaki white spaceler eger varsa atlanir
    while (line[i] == ' ' || line[i] == '\t' || i >= line.size())
        i++;
 
    // Line icindeki ilk string alınarak Instruction'a doldurulur.
    if (i < line.size()) {
        while (line[i] != ' ' && line[i] != '\t' && i < line.size()) {
            instruction += line[i];
            ++i;
        }
        read++;
    }
 
    //white spaceler atlanır 
    while (line[i] == ' ' || line[i] == '\t' || i >= line.size())
        i++;
 
    //Line icindeki 2. string alinarak command1'e doldurulur, geçerli bir input olup olmadigi kontrol edilir.
    //Hatali ise 0 return edilir.
    if (i < line.size()) {
        while (line[i] != ' ' && line[i] != '\t' && line[i] != ';' && i < line.size()) {
            command1 += line[i];
            ++i;
        }
        //Register check
        if ((command1[0] == 'R' || command1[0] == 'r')) {
            if (-1 != command1.find_first_not_of("Rr12345,"))
                return 0;
        }//Constant check
        else if (('1' <= command1[0] <= '9') || (command1[0]== '-')) {
            if (-1 != command1.find_first_not_of("1234567890-"))
                return 0; 
        }//Invalid Input
        else {
            return 0;
        }
        if (command1.size() >= 1)
            read++;
    }
 
    //Whitespace'ler atlanir
    while (line[i] == ' ' || line[i] == '\t' || i >= line.size())
        i++;
 
    // Eger varsa line icindeki 3. string alinarak command2'e doldurulur, geçerli bir input olup olmadigi kontrol edilir.
    //Hatali ise 0 return edilir.
    if (i < line.size()) {
        while (line[i] != ' ' && line[i] != '\t' && line[i] != ';' && i < line.size()) {
            command2 += line[i];
            ++i;
        }
 
        //Register Check
        if ((command2[0] == 'R' || command2[0] == 'r')) {
            if (-1 != command1.find_first_not_of("Rr12345,"))
                return 0;
        }//Constant check
        else if (('1' <= command2[0] <= '9') || (command2[0]== '-')) {
            if (-1 != command2.find_first_not_of("1234567890-"))
                return 0;
        }//Invalid Input
        else {
            return 0;
        }
        if (command2.size() >= 1)
            read++;
    }
 
    return read;
}
 
//Integer'dan olusan stringleri integer olarak return eden func.
int HandMadeAtoi(string strLine) {
    int integerValue = 0;
 
    if (strLine[0] == '-') {
        for (int i = 1; i < strLine.size(); ++i) {
            integerValue += ((int) (strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
        }
        integerValue *= -1;
    } else
        for (int i = 0; i < strLine.size(); ++i) {
            integerValue += ((int) (strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
        }
 
    return integerValue;
}
