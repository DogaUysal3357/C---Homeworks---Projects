/* 
 * File:   CPU.cpp
 * Author: Doğa
 * 
 * Created on 29 Ekim 2016 Cumartesi, 16:37
 */

#ifndef CPU_H
#define	CPU_H

#include <string>
#include <iostream>
#include <cmath> // for pow func
#include "Memory.h"

const int CONST_JMP = 0;
const int REG_JMP = 1;
const int OPT_MEMORY = 1;

using namespace std;


const int REGISTER_SIZE = 5;

class CPU {
public:
    CPU();
    CPU(int opt);

    //Okunan lineların teker teker execute eidlerek gerekli instructionların cagirildigi func
    int Execute(string line, Memory& memoryLoc);
    // Programin halt edilip edilmedigini return eden func
    bool Halted();
    // Register degerlerini ekrana basan func
    void Print(Memory& memoryLoc);
    // Programi halt eden func
    void Halt(Memory& memoryLoc);
    // Istenen registeri return eden func
    int getRegisterVal(int registerNum);
    // Istenen registerin degistirilmesini saglayan func
    void setRegisterVal(int registerNum, int registerVal);
    int getPC();
    void setPC(int _pc);
	void setOPT(int _opt);
    CPU(const CPU& orig);
private:

    // Register arrayi
    int registers[REGISTER_SIZE];
    // Okunacak line bilgisini tutan ProgramCounter
    int PC;
    int option;
    bool halted;
    // Line icindeki instruction stringi
    string instruction;
    // Line icindeki 1. command
    string command1;
    // Line icindeki 2.command
    string command2;

    //Parse elemanlarının içlerini boşaltıp yeniden kullanıma hazır hale getirir.
    void ResetParseElems();
    void setHalt(bool _h);
    // Move Instruction
    void Move(Memory& memoryLoc);
    // Add Instruction
    void Add(Memory& memoryLoc);
    // Substract Instruction
    void Substract(Memory& memoryLoc);
    // Jump Instruction.  
    // opt -> 1 , Register check, jump
    // opt -> 0,  constant jump
    int Jump(int opt);
    int JPN();
    // Stringleri int'e ceviren func
    int HandMadeAtoi(string comm, int option=0);
    // Satirlari parslayarak instruction funclarini cagfiran func
    int FillUpParams(string line);

};

#endif	/* CPU_H */

