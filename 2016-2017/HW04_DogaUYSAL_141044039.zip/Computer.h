﻿/* 
 * File:   Computer.h
 * Author: Doğa
 *
 * Created on 29 Ekim 2016 Cumartesi, 16:50
 */

#ifndef COMPUTER_H
#define	COMPUTER_H

#include "CPU.h"
#include "CPUProgram.h"
#include "Memory.h"
using namespace std;

class Computer {
public:
    Computer();
    Computer(int option);
    Computer(CPU _myCpu, CPUProgram _myProg, Memory _myMemory, int option);
    Computer(const Computer& orig);
    virtual ~Computer();

    //Programin calistirildigi func. CPU execute calistirilarak CPUProgram esliginde gerekli islemler yapilir.
    void Execute(char* filename, int option);
    void setCPU(const CPU& cpu2);
    void setCPUProgram(const CPUProgram& prog2);
    void setMemory(const Memory& memory2);
    void setOption(int opt);
    CPU getCPU();
    CPUProgram getCPUProgram();
    Memory getMemory();
    int getOption();

private:
    CPU myCPU;
    CPUProgram myProg;
    Memory myMemory;
    int option;
};

#endif	/* COMPUTER_H */

