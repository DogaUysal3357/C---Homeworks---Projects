/* 
 * File:   Computer.cpp
 * Author: Doğa
 * 
 * Created on 29 Ekim 2016 Cumartesi, 16:50
 */

#include "Computer.h"


Computer::Computer() {
    myCPU = CPU();
    myProg = CPUProgram();
    myMemory = Memory();
    setOption(0);
}

Computer::Computer(int option) {
    myCPU = CPU();
    myProg = CPUProgram();
    myMemory = Memory();
    setOption(option);
}

Computer::Computer(CPU _myCpu, CPUProgram _myProg, Memory _myMemory, int option) {
    myCPU = _myCpu;
    myProg = _myProg;
    myMemory = _myMemory;
    this->option = option;
}

// Programin calistirildigi func. CPUProgramdan linelar alinir. CPU.execute ile okunan linelarla islemler yapilir.
void Computer::Execute(char* filename, int option) {
    int newLineAdress = 0;
    myProg.ReadFile(filename);
    myCPU.setOPT(option);
	myCPU.setPC(1);
	
    while (!myCPU.Halted()) {

        newLineAdress = myCPU.Execute(myProg.getLine(myCPU.getPC()), myMemory);
        if (newLineAdress == -1) { // -1 return edilirse JMP yakalanmamis demektir. Sonraki satira gecilir.
            myCPU.setPC(myCPU.getPC() + 1);
        } else if (newLineAdress == -2) { // -2 return edildiyse program halt edilmesi gerekmektedir demektedir. 
            myCPU.Halt(myMemory);
        } else { // Eger pozitif bir deger return edilmisse JMP instrucitonı gelmis demektir. PC gerekli sekilde update edilir.    
            myCPU.setPC(newLineAdress);
        }
    }
}

void Computer::setOption(int opt) {
    option = opt;
}

void Computer::setMemory(const Memory& memory2) {
    myMemory = memory2;
}

void Computer::setCPU(const CPU& cpu2) {
    myCPU = cpu2;
}

void Computer::setCPUProgram(const CPUProgram& prog2) {
    myProg = prog2;
}

CPU Computer::getCPU() {
    return myCPU;
}

CPUProgram Computer::getCPUProgram() {
    return myProg;
}

Memory Computer::getMemory() {
    return myMemory;
}

int Computer::getOption() {
    return option;
}

Computer::Computer(const Computer& orig) {
    myProg = CPUProgram(orig.myProg);
    myCPU = CPU(orig.myCPU);
    myMemory = Memory(orig.myMemory);
    option = orig.option;
}

Computer::~Computer() {
}

