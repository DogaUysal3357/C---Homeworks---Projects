/* 
 * File:   CPUProgram.cpp
 * Author: Doğa
 * 
 * Created on 29 Ekim 2016 Cumartesi, 16:40
 */
#include "CPUProgram.h"

CPUProgram::CPUProgram() {
    size = 0;
}

CPUProgram::CPUProgram(const CPUProgram& orig) {
    size = orig.size;
    for (int i = 0; i < MAX_LINE_SIZE; ++i) {
        lines[i] = orig.lines[i];
    }
}

void CPUProgram::ReadFile(char* fileName) {
    ifstream inFile;

    inFile.open(fileName);

    if (inFile.is_open()) {// dosya acinarak okuma yapilir.
        while (getline(inFile, lines[size])) {
            IncrementSize();
            if (size > MAX_LINE_SIZE + 1) {
                cout << " Max File Size is 200" << endl;
                exit(EXIT_FAILURE);
            }
        }
    } else { // Dosya bulunamadıysa hata mesajı verilerek cikis yapilir
        cout << "Could not open the file named -> " << fileName << endl;
        exit(EXIT_FAILURE);
    }

    inFile.close();
}

string CPUProgram::getLine(int lineNum) {
    return lines[lineNum - 1];
}

void CPUProgram::IncrementSize() {
    size+=1;
}
