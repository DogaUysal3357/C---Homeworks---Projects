/* 
 * File:   Memory.cpp
 * Author: Doğa
 * 
 * Created on 29 Ekim 2016 Cumartesi, 16:41
 */

#include "Memory.h"

Memory::Memory() {
    for (int i = 0; i < MEMORY_SIZE; ++i) {
        setMemory(i, 0);
    }
}

Memory::Memory(const Memory& orig) {
    for (int i = 0; i < MEMORY_SIZE; ++i) {
        memory[i] = orig.memory[i];
    }
}

void Memory::PrintAll() {

    cout << "Memory Values : " << endl;

    for (int i = 0; i < MEMORY_SIZE; ++i) {
        cout << "#" << i << " -> " << getMemory(i) << endl;
    }
}

unsigned int Memory::getMemory(int index) {
    return memory[index];
}

void Memory::setMemory(int index, int value) {
    memory[index] = value;
}
