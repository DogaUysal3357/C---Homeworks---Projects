/* 
 * File:   CPU.cpp
 * Author: Doğa
 * 
 * Created on 29 Ekim 2016 Cumartesi, 16:37
 */
#include "CPU.h"

CPU::CPU(int opt) {
    for (int i = 0; i < REGISTER_SIZE; i++) {
        registers[i] = 0;
    }
    PC = 1;
    option = opt;
    halted = false;
    instruction = "";
    command1 = "";
    command2 = "";
}

CPU::CPU() {
    CPU(0);
}

CPU::CPU(const CPU& orig) {
    for (int i = 0; i < REGISTER_SIZE; ++i) {
        registers[i] = orig.registers[i];
    }
    PC = orig.PC;
    option = orig.option;
    halted = orig.halted;
    instruction = orig.instruction;
    command1 = orig.command1;
    command2 = orig.command2;
}

void CPU::ResetParseElems() {
    instruction = "";
    command1 = "";
    command2 = "";
}

int CPU::Execute(string line, Memory& memoryLoc) {
    int read = 0;

    ResetParseElems();

    read = FillUpParams(line);
    if ((read <= 1) && !(instruction == "HLT" || instruction == "hLT" || instruction == "hlT" || instruction == "hlt" || instruction == "hLt" || instruction == "Hlt" || instruction == "hlT" || instruction == "hLt")) {
        cout << "Invalid Input : " << line << endl
                << "Input Format : 'Insturction Command1, Command2' or 'Instruction Command' " << endl;
        return -2;
    }

    if (option != 0) {
        cout << "Executed Command -> " << line << endl
                << "Registers :" << endl;
        for (int i = 0; i < REGISTER_SIZE; ++i) {
            cout << 'R' << (i + 1) << " : " << getRegisterVal(i) << endl;
        }
    }
    if (option == 2) {
        cout << "Memories :" << endl;
        for (int i = 0; i < MEMORY_SIZE; ++i) {
            cout << '#' << (i) << " : " << memoryLoc.getMemory(i) << endl;
        }
    }

    if (instruction == "MOV" || instruction == "mOV" || instruction == "moV" || instruction == "mov"
            || instruction == "MoV" || instruction == "Mov" || instruction == "moV" || instruction == "mOv") {
        if (read != 3) {
            return -2;
        } else
            Move(memoryLoc);
    } else if (instruction == "ADD" || instruction == "aDD" || instruction == "adD" || instruction == "add"
            || instruction == "AdD" || instruction == "Add" || instruction == "adD" || instruction == "aDd") {
        if (read != 3) {
            return -2;
        } else
            Add(memoryLoc);
    } else if (instruction == "SUB" || instruction == "sUB" || instruction == "suB" || instruction == "sub"
            || instruction == "SuB" || instruction == "Sub" || instruction == "suB" || instruction == "sUb") {
        if (read != 3) {
            return -2;
        } else
            Substract(memoryLoc);
    } else if (instruction == "JMP" || instruction == "jMP" || instruction == "jmP" || instruction == "jmp"
            || instruction == "JmP" || instruction == "Jmp" || instruction == "jmP" || instruction == "jMp") {
        if (read == 2) {
            return Jump(CONST_JMP);
        } else if (read == 3) {
            return Jump(REG_JMP);
        } else
            return -2;
    } else if (instruction == "PRN" || instruction == "pRN" || instruction == "prN" || instruction == "prn"
            || instruction == "PrN" || instruction == "Prn" || instruction == "prN" || instruction == "pRn") {
        if (read != 2) {
            return -2;
        } else
            Print(memoryLoc);
    } else if (instruction == "JPN" || instruction == "jPN" || instruction == "jpN" || instruction == "jpn"
            || instruction == "jPn" || instruction == "Jpn" || instruction == "jpN" || instruction == "jPn") {
        return JPN();
    } else if (instruction == "HLT" || instruction == "hLT" || instruction == "hlT" || instruction == "hlt"
            || instruction == "hLt" || instruction == "Hlt" || instruction == "hlT" || instruction == "hLt") {
        return -2;
    } else {
        cout << "Invalid Input : " << line << endl
                << "Input Format : 'Insturction Command1, Command2' or 'Instruction Command' " << endl;
        return -2;
    }
    return -1;
}

void CPU::Move(Memory & memoryLoc) {
    int register1 = 0;
    int register2 = 0;
    
    if ((command1[0] == 'R') || (command1[0] == 'r')) { //comm1 is a register
        register1 = (int) (command1[1] - '1');
        if (command2[0] == '#') { //ocom2 is a memory address
            register2 = HandMadeAtoi(command2, OPT_MEMORY);
            memoryLoc.setMemory(register2, getRegisterVal(register1));
        } else if ((command2[0] == 'R') || (command2[0] == 'r')) { // comm2 is a register
            register2 = (int) (command2[1] - '1');
            setRegisterVal(register2, getRegisterVal(register1));
        } else { // comm2 is a constant
            setRegisterVal(register1, HandMadeAtoi(command2));
        }
    } else if (command1[0] == '#') { // comm1 is a memory address
        register1 = HandMadeAtoi(command1, OPT_MEMORY);

        if ((command2[0] == 'R') || (command2[0] == 'r')) { // comm2 is a register
            register2 = (int) (command2[1] - '1');
            setRegisterVal(register2, memoryLoc.getMemory(register1));
        } else { // comm2 is a constant
            memoryLoc.setMemory(register1, HandMadeAtoi(command2));
        }

    }


}

void CPU::Add(Memory & memoryLoc) {

    int register1 = 0;
    int register2 = 0;

    register1 = (int) (command1[1] - '1');

    if ((command2[0] == 'R') || (command2[0] == 'r')) { // comm2 is a register
        register2 = (int) (command2[1] - '1');
        setRegisterVal(register1, getRegisterVal(register1) + getRegisterVal(register2));
    } else if (command2[0] == '#') { // comm2 is a memory address
        register2 = HandMadeAtoi(command2, OPT_MEMORY);
        setRegisterVal(register1, getRegisterVal(register1) + memoryLoc.getMemory(register2));
    } else { // comm2 is a constant
        setRegisterVal(register1, getRegisterVal(register1) + HandMadeAtoi(command2));
    }


}

void CPU::Substract(Memory & memoryLoc) {
    int register1 = 0;
    int register2 = 0;

    register1 = (int) (command1[1] - '1');

    if ((command2[0] == 'R') || (command2[0] == 'r')) { // comm2 is a register
        register2 = (int) (command2[1] - '1');
        setRegisterVal(register1, getRegisterVal(register1) - getRegisterVal(register2));
    } else if (command2[0] == '#') { // comm2 is a memory address
        register2 = HandMadeAtoi(command2, OPT_MEMORY);
        setRegisterVal(register1, getRegisterVal(register1) - memoryLoc.getMemory(register2));
    } else { // comm2 is a constant
        setRegisterVal(register1, getRegisterVal(register1) - HandMadeAtoi(command2));
    }
}

int CPU::Jump(int opt) {
    int newAdress = -1;
    int register1 = 0;

    if (opt == 1) {
        register1 = (int) (command1[1] - '1');
        if (getRegisterVal(register1) == 0) {
            newAdress = HandMadeAtoi(command2);
        }

        return newAdress;
    } else {
        return HandMadeAtoi(command1);
    }
}

int CPU::JPN() {
    int newAdress = -1;
    int registerValue = 0;

    registerValue = (int) (command1[1] - '1');
    if (getRegisterVal(registerValue) <= 0) {
        newAdress = HandMadeAtoi(command2);
    }
    return newAdress;
}

void CPU::Print(Memory& memoryLoc) {
    int reg = 0;

    if (command1[0] == '#') { // comm is a memory address
        cout << memoryLoc.getMemory(HandMadeAtoi(command1, OPT_MEMORY)) << endl;
    }
    if ((command1[0] != 'R') && (command1[0] != 'r')) { // comm is a constant      
        cout << command1 << endl;
    } else { // comm is a register
        reg = (int) (command1[1] - '1');
        cout << getRegisterVal(reg) << endl;
    }
}

void CPU::Halt(Memory& memoryLoc) {
    setHalt(true);
    cout << "Program halted. Registers : " << endl;
    for (int i = 0; i < REGISTER_SIZE; i++) {
        cout << 'R' << (i + 1) << " : " << getRegisterVal(i) << endl;
    }
    cout << "Memories : " << endl;
    for (int i = 0; i < MEMORY_SIZE; i++) {
        cout << '#' << i << " : " << memoryLoc.getMemory(i) << endl;
    }
}

bool CPU::Halted() {
    return halted;
}

int CPU::FillUpParams(std::string line) {
    int read = 0;
    int i = 0;
 
    // Baslangictaki white spaceler eger varsa atlanir
    while (line[i] == ' ' || line[i] == '\t' || i >= line.size()) 
        i++;


    // Line icindeki ilk string alınarak Instruction'a doldurulur.
    if (i < line.size()) {
        while (line[i] != ' ' && line[i] != '\t' && i < line.size()) {
            instruction += line[i];
            ++i;
        }
        read++;
    }
 
    //white spaceler atlanır 
    while (line[i] == ' ' || line[i] == '\t'){
        i++;
		if(i == line.size() ) 
			break;	
	}

    //Line icindeki 2. string alinarak command1'e doldurulur, geçerli bir input olup olmadigi kontrol edilir.
    //Hatali ise 0 return edilir.
    if (i < line.size()) {
        while (line[i] != ' ' && line[i] != '\t' && line[i] != ';' && i < line.size()) {
            command1 += line[i];
            ++i;
        }

        //Register check
        if ((command1[0] == 'R' || command1[0] == 'r')) {
            if (-1 != command1.find_first_not_of("Rr12345,"))
                return 0;
        }//Memory Address check 
        else if ((command1[0] == '#')) {
            if (-1 != command1.find_first_not_of("#1234567890,")) {
                return 0;
            }
        }//Constant check
        else if (('1' <= command1[0] <= '9') || (command1[0] == '-')) {

            if (-1 != command1.find_first_not_of("1234567890-"))
                return 0;
        }//Invalid Input
        else {
            return 0;
        }
        if (command1.size() >= 1)
            read++;
    }
 
    //Whitespace'ler atlanir
    while (line[i] == ' ' || line[i] == '\t'){
        i++;
		if(i == line.size() ) 
			break;	
	}
 
    // Eger varsa line icindeki 3. string alinarak command2'e doldurulur, geçerli bir input olup olmadigi kontrol edilir.
    //Hatali ise 0 return edilir.
    if (i < line.size()) {
        while (line[i] != ' ' && line[i] != '\t' && line[i] != ';' && i < line.size()) {
            command2 += line[i];
            ++i;
        }
        //Register Check
        if ((command2[0] == 'R' || command2[0] == 'r')) {
            if (-1 != command2.find_first_not_of("Rr12345"))
                return 0;
        }//Memory Address check 
        else if ((command2[0] == '#')) {
            if (-1 != command2.find_first_not_of("#1234567890")) {
                return 0;
            }
        }//Constant check
        else if (('1' <= command2[0] <= '9') || (command2[0] == '-')) {

            if (-1 != command2.find_first_not_of("1234567890-"))
                return 0;
        }//Invalid Input
        else {
            return 0;
        }
 
        if (command2.size() >= 1)
            read++;
    }
 
    return read;
}


// Integer'dan olusan stringleri integer olarak return eden func.
// option -> for Constant
// option -> 1 for Memory
int CPU::HandMadeAtoi(string strLine, int option) {
    int integerValue = 0;

    if (option == 0) {
        if (strLine[0] == '-') {
            for (int i = 1; i < strLine.size(); ++i) {
                integerValue += ((int) (strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
            }
            integerValue *= -1;
        } else
            for (int i = 0; i < strLine.size(); ++i) {
                integerValue += ((int) (strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
            }
    } else {
        if (strLine[strLine.size() - 1] == ',') {
            for (int i = 1; i < (strLine.size() - 1); ++i) {
                integerValue += ((int) (strLine[i] - '0')) * pow(10, strLine.size() - i - 2);
            }
        } else {
            for (int i = 1; i < strLine.size(); ++i) {
                integerValue += ((int) (strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
            }
        }
    }
    return integerValue;
}

int CPU::getPC() {
    return PC;
}

void CPU::setPC(int _pc) {
    PC = _pc;
}

void CPU::setOPT(int _opt){
	option = _opt;
}

void CPU::setHalt(bool _h) {
    halted = _h;
}

void CPU::setRegisterVal(int registerNum, int registerVal) {
    registers[registerNum] = registerVal;
}

int CPU::getRegisterVal(int registerNum) {
    return registers[registerNum];
}


