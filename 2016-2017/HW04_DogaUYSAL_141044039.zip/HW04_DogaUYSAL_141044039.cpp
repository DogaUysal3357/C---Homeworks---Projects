/* 
 * File:   main.cpp
 * Author: Doğa
 *
 * Created on 27 Ekim 2016 Perşembe, 18:23
 */

#include <cstdlib>

#include "Computer.h"

using namespace std;

int main(int argc, char** argv) {
    int option = 0;

    // Program gerekli argumanalrla çalıştırılmışmı diye kontrol edilir.
    if (argc != 3) {
        cout << "Usage : programName filename option  " << endl;
        return 1;
    }

    // Option argumanin dogru girilip girilmediginin kontrolu
    if (argv[2][0] == '1') {
        option = 1;
    } else if (argv[2][0] == '0') {
        option = 0;
    } else if (argv[2][0] == '2') {
        option = 2;
    } else {
        cout << "Option can only be 0 | 1 | 2" << endl;
        return 1;
    }

	//Computer yaratılarak computer calistirilir.
    Computer myComputer;
    myComputer.Execute(argv[1], option);


    return 0;
}

