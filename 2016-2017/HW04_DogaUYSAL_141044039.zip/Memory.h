﻿/* 
 * File:   Memory.h
 * Author: Doğa
 *
 * Created on 29 Ekim 2016 Cumartesi, 16:41
 */

#ifndef MEMORY_H
#define	MEMORY_H


#include <iostream>
using namespace std;
const int MEMORY_SIZE = 50;

class Memory {
public:
    Memory();
    
    unsigned int getMemory(int index);
    void setMemory(int index, int value);
    void PrintAll();
    
    Memory(const Memory& orig);
private:
    unsigned int memory[MEMORY_SIZE];
};

#endif	/* MEMORY_H */

