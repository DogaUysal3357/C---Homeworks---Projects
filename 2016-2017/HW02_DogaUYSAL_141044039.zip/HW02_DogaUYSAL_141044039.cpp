/*
* File:   main.cpp
* Author: Doğa UYSAL 141044039
*
* Created on 08 Ekim 2016 Cumartesi, 14:49
*/

#include <iostream>
#include <fstream>
#include <string.h>
#include <cmath> // HandMadeAtoi icinde pow alabilmek icin kullanıldı

using namespace std;

/* Okunan line teker teker instruction ve command'ler olmak uzere parcalanir
* Parcalanma islemi yapildiktan sonra instructionlar gerekli sekilde gerceklestirilir.
* Inputlarda hata varsa gerekli degerler donulerek Halt edilir.*/
int Execute(string line, int *regValue, unsigned int* memoryArr, int option);
//2 adet string ve register array'ini alarak, constant mi yoksa register mi olduklari kontrol edilerek gerekli atama islemi yapılır.
void Move(string comm1, string comm2, int* regValue, unsigned int* memoryArr);
//2 adet command stringi ve register arrayi alinarak gerekli toplama islemleri yapilir ve register'a atanir.
void Add(string comm1, string comm2, int* regValue, unsigned int* memoryArr);
//2 adet command string'i ve register arrayi alinir. Constant ve register ayristirmalari yapildiktan sonra çıkarma islemi yapılarak gerekli register'a atanir
void Substract(string comm1, string comm2, int* regValue, unsigned int* memoryArr);
// 2 adet string ve register arrayi alinir. Eger istenen register 0 ise verilen adress return edilir.
// Register 0 degilse -1 donulerek bir sonraki line'a gecilmesi isaret edilir.
int Jump(string adress);
// Verilen constant deger int olarak return edilerek, o line'a gecis yapilmasi gerektigi belirtilir.
int Jump(string reg, string adress, int* regValue);
// Verilen constant deger int olarak return edilerek, o line'a geçiş yapilmasi gerektigini belirtilir.
int JPN(string reg, string adress, int* regValue);
//Command stringi ve register arrayi alinir. Istenen degerler ekrana basilir.
void Print(string comm, int* regValue, unsigned int* memoryArr);
// Programin sonlandigi belirtilerek, tum registerlar iclerindeki degerler ile ekrana basilir.
void Halt(int* regValue, unsigned int* memoryArr);

// stringleri int'e çeviren func
int HandMadeAtoi(string strLine, int option = 0);
/* Okunan line gerekli sekilde instruction ve commandler olarak ayristirilir.
* "Instruction command1, command2"
* "Instruction command " formatinda olmayan tüm line'lar hatalı olarak varsayılır. */
int FillUpParams(string line, string& instruction, string& command1, string& command2);

const int MAX_LINE = 200;
const int REGISTER_SIZE = 5;
const int MEMORY_SIZE = 50;
const int OPT_MEMORY = 1;

int main(int argc, char** argv) {

	int regValue[REGISTER_SIZE] = { 0, 0, 0, 0, 0 };
	unsigned int memoryArr[MEMORY_SIZE];
	string lines[MAX_LINE];
	int option = 0;
	int lineAdress = 0;
	int newLineAdress = 0;
	bool halted = false;
	ifstream inFile;
	int i = 0;

	//Arguman kontrolu
	if (argc != 3) {
		cout << "Usage : programName filename option  " << endl;
		return 1;
	}

	// Option argumanin dogru girilip girilmediginin kontrolu
	if (argv[2][0] == '1') {
		option = 1;
	}
	else if (argv[2][0] == '0') {
		option = 0;
	}
	else if (argv[2][0] == '2') {
		option = 2;
	}
	else {
		cout << "Option can only be 0 | 1 | 2" << endl;
		return 1;
	}

	inFile.open(argv[1]);

	//Dosya eger dogru yazilmissa okunmaya baslanir. Eger istenen dosya bulunamazsa bilgilendirici output ekrana basilir ve programdan cikis yapilir.
	if (inFile.is_open()) {
		while (getline(inFile, lines[i])) {
			++i;
		}
	}
	else {
		cout << "Could not open the file named -> " << argv[1] << endl;
		return 1;
	}

	// Program halt edilene kadar dongu icinde calisir.
	// Okunann her line execute fonksyonu icine, register bilgileri ve option ile birlikte gonderilir.
	// Execute'un return ettigi degere gore hangi line gecis yapilacagi belirlenir.
	// return -2 -> Program Halt edilecektir.
	// return -1 -> Bir sonraki line'a gecilecek
	// Diger tum degeler -> Donulen degerin line'ına gecis yapilir.
	while (!halted) {
		newLineAdress = Execute(lines[lineAdress], regValue, memoryArr, option);

		if (newLineAdress == -1) {
			lineAdress += 1;

		}
		else if (newLineAdress == -2) {
			Halt(regValue, memoryArr);
			halted = true;
		}
		else {
			lineAdress = newLineAdress - 1;
		}


	}

	//Dosya kapanir
	inFile.close();

	return 0;
}

// Okunan line teker teker instruction ve command'ler olmak uzere parcalanir
// Parcalanma islemi yapildiktan sonra instructionlar gerekli sekilde gerceklestirilir.
// Inputlarda hata varsa gerekli degerler donulerek Halt edilir.
// Return edilen integer deger, bu execute isleminden sonra hangi line'a gecilecegini belirtir.

int Execute(string line, int *regValue, unsigned int* memoryArr, int option) {

	string instruction = "",
		command1 = "",
		command2 = "";
	int read = 0; // Alinan line parcalandiktan sonra icinden cikan string sayisi

	read = FillUpParams(line, instruction, command1, command2);
	//Yeterli sayida string okunup okunmadigiin kontrolu
	if ((read <= 1) && !(instruction == "HLT" || instruction == "hLT" || instruction == "hlT" || instruction == "hlt" || instruction == "hLt" || instruction == "Hlt" || instruction == "hlT" || instruction == "hLt")) {
		cout << "Invalid Input : " << line << endl
			<< "Input Format : 'Insturction Command1, Command2' or 'Instruction Command' " << endl;
		return -2;
	}

	if (instruction == "MOV" || instruction == "mOV" || instruction == "moV" || instruction == "mov"
		|| instruction == "MoV" || instruction == "Mov" || instruction == "moV" || instruction == "mOv") {
		if (read != 3) { // Yeterli sayida input oldugunun kontrolu
			return -2;
		}
		else
			Move(command1, command2, regValue, memoryArr);
	}
	else if (instruction == "ADD" || instruction == "aDD" || instruction == "adD" || instruction == "add"
		|| instruction == "AdD" || instruction == "Add" || instruction == "adD" || instruction == "aDd") {
		if (read != 3) { // Yeterli sayida input oldugunun kontrolu
			return -2;
		}
		else
			Add(command1, command2, regValue, memoryArr);
	}
	else if (instruction == "SUB" || instruction == "sUB" || instruction == "suB" || instruction == "sub"
		|| instruction == "SuB" || instruction == "Sub" || instruction == "suB" || instruction == "sUb") {
		if (read != 3) { // Yeterli sayida input oldugunun kontrolu
			return -2;
		}
		else
			Substract(command1, command2, regValue, memoryArr);
	}
	else if (instruction == "JMP" || instruction == "jMP" || instruction == "jmP" || instruction == "jmp"
		|| instruction == "JmP" || instruction == "Jmp" || instruction == "jmP" || instruction == "jMp") {
		if (read == 2) {
			return Jump(command1);
		}
		else if (read == 3) {
			return Jump(command1, command2, regValue);
		}
		else
			return -2;
	}
	else if (instruction == "PRN" || instruction == "pRN" || instruction == "prN" || instruction == "prn"
		|| instruction == "PrN" || instruction == "Prn" || instruction == "prN" || instruction == "pRn") {
		if (read != 2) { // Yeterli sayida input oldugunun kontrolu
			return -2;
		}
		else
			Print(command1, regValue, memoryArr);
	}
	else if (instruction == "HLT" || instruction == "hLT" || instruction == "hlT" || instruction == "hlt"
		|| instruction == "hLt" || instruction == "Hlt" || instruction == "hlT" || instruction == "hLt") {
		return -2;
	}
	else if (instruction == "JPN" || instruction == "jPN" || instruction == "jpN" || instruction == "jpn"
		|| instruction == "jPn" || instruction == "Jpn" || instruction == "jpN" || instruction == "jPn") {
		return JPN(command1, command2, regValue);
	}
	else { // Gecersin Instriction girisi
		cout << "Invalid Input : " << line << endl
			<< "Input Format : 'Insturction Command1, Command2' or 'Instruction Command' " << endl;
		return -2;
	}

	if (option != 0) {
		cout << "Executed Command -> " << line << endl
			<< "Registers :" << endl;
		for (int i = 0; i < REGISTER_SIZE; ++i) {
			cout << 'R' << (i + 1) << " : " << regValue[i] << endl;
		}
	}
	if (option == 2) {
		cout << "Memories :" << endl;
		for (int i = 0; i < MEMORY_SIZE; ++i) {
			cout << '#' << (i) << " : " << memoryArr[i] << endl;
		}
	}
	return -1;
}

//2 adet string ve register array'ini alarak, constant mi yoksa register mi olduklari kontrol edilerek gerekli atama islemi yapılır.

void Move(string comm1, string comm2, int *regValue, unsigned int* memoryArr) {
	int register1 = 0;
	int register2 = 0;


	if ((comm1[0] == 'R') || (comm1[0] == 'r')) { //comm1 is a register
		register1 = (int)(comm1[1] - '1');
		if (comm2[0] == '#') { //ocom2 is a memory address
			register2 = HandMadeAtoi(comm2, OPT_MEMORY);
			memoryArr[register2] = regValue[register1];
		}
		else if ((comm2[0] == 'R') || (comm2[0] == 'r')) { // comm2 is a register
			register2 = (int)(comm2[1] - '1');
			regValue[register2] = regValue[register1];
		}
		else { // comm2 is a constant
			regValue[register1] = HandMadeAtoi(comm2);
		}
	}
	else if (comm1[0] == '#') { // comm1 is a memory address
		register1 = HandMadeAtoi(comm1, OPT_MEMORY);
		if ((comm2[0] == 'R') || (comm2[0] == 'r')) { // comm2 is a register
			register2 = (int)(comm2[1] - '1');
			regValue[register2] = memoryArr[register1];

		}
		else { // comm2 is a constant
			memoryArr[register1] = HandMadeAtoi(comm2);
		}

	}
}

//2 adet command stringi ve register arrayi alinarak gerekli toplama islemleri yapilir ve register'a atanir.

void Add(string comm1, string comm2, int *regValue, unsigned int* memoryArr) {
	int register1 = 0;
	int register2 = 0;

	register1 = (int)(comm1[1] - '1');

	if ((comm2[0] == 'R') || (comm2[0] == 'r')) { // comm2 is a register
		register2 = (int)(comm2[1] - '1');
		regValue[register1] += regValue[register2];
	}
	else if (comm2[0] == '#') { // comm2 is a memory address
		register2 = HandMadeAtoi(comm2, OPT_MEMORY);
		regValue[register1] += memoryArr[register2];
	}
	else { // comm2 is a constant
		regValue[register1] += HandMadeAtoi(comm2);
	}
}

//2 adet command string'i ve register arrayi alinir. Constant ve register ayristirmalari yapildiktan sonra çıkarma islemi yapılarak gerekli register'a atanir

void Substract(string comm1, string comm2, int *regValue, unsigned int* memoryArr) {
	int register1 = 0;
	int register2 = 0;

	register1 = (int)(comm1[1] - '1');

	if ((comm2[0] == 'R') || (comm2[0] == 'r')) { // comm2 is a register
		register2 = (int)(comm2[1] - '1');
		regValue[register1] -= regValue[register2];
	}
	else if (comm2[0] == '#') { // comm2 is a memory address
		register2 = HandMadeAtoi(comm2, OPT_MEMORY);
		regValue[register1] -= memoryArr[register2];
	}
	else { // comm2 is a constant
		regValue[register1] -= HandMadeAtoi(comm2);
	}
}

// 2 adet string ve register arrayi alinir. Eger istenen register 0 ise verilen adress return edilir.
// Register 0 degilse -1 donulerek bir sonraki line'a gecilmesi isaret edilir.

int Jump(string reg, string adress, int *regValue) {
	int newAdress = -1;
	int register1 = 0;

	register1 = (int)(reg[1] - '1');
	if (regValue[register1] == 0) {
		newAdress = HandMadeAtoi(adress);
	}

	return newAdress;
}

// Verilen constant deger int olarak return edilerek, o line'a gecis yapilmasi gerektigi belirtilir.

int Jump(string adress) {
	return HandMadeAtoi(adress);
}

int JPN(string reg, string adress, int* regValue) {
	int newAdress = -1;
	int registerValue = 0;

	registerValue = (int)(reg[1] - '1');
	if (regValue[registerValue] <= 0) {
		newAdress = HandMadeAtoi(adress);
	}
	return newAdress;
}



//Command stringi ve register arrayi alinir. Istenen degerler ekrana basilir.

void Print(string comm, int *regValue, unsigned int* memoryArr) {
	int reg = 0;

	if (comm[0] == '#') { // comm is a memory address
		cout << memoryArr[HandMadeAtoi(comm, OPT_MEMORY)] << endl;
	}
	if ((comm[0] != 'R') && (comm[0] != 'r')) { // comm is a constant      
		cout << comm << endl;
	}
	else { // comm is a register
		reg = (int)(comm[1] - '1');
		cout << regValue[reg] << endl;
	}
}

// Programin sonlandigi belirtilerek, tum registerlar iclerindeki degerler ile ekrana basilir.

void Halt(int* regValue, unsigned int* memoryArr) {
	cout << "Program halted. Registers : " << endl;
	for (int i = 0; i < REGISTER_SIZE; i++) {
		cout << 'R' << (i + 1) << " : " << regValue[i] << endl;
	}
	cout << "Memories : " << endl;
	for (int i = 0; i < MEMORY_SIZE; i++) {
		cout << '#' << i << " : " << memoryArr[i] << endl;
	}
}

/* Okunan line gerekli sekilde instruction ve commandler olarak ayristirilir.
* "Instruction command1, command2"
* "Instruction command " formatinda olmayan tüm line'lar hatalı olarak varsayılır.*/
int FillUpParams(string line, string &instruction, string &command1, string &command2) {
	int read = 0;
	int i = 0;


	// Baslangictaki white spaceler eger varsa atlanir
	while (line[i] == ' ' || line[i] == '\t' || i >= line.size())
		i++;

	// Line icindeki ilk string alınarak Instruction'a doldurulur.
	if (i < line.size()) {
		while (line[i] != ' ' && line[i] != '\t' && i < line.size()) {
			instruction += line[i];
			++i;
		}
		read++;
	}

	//white spaceler atlanır 
	while (line[i] == ' ' || line[i] == '\t') {
		i++;
		if (i == line.size())
			break;
	}

	//Line icindeki 2. string alinarak command1'e doldurulur, geçerli bir input olup olmadigi kontrol edilir.
	//Hatali ise 0 return edilir.
	if (i < line.size()) {
		while (line[i] != ' ' && line[i] != '\t' && line[i] != ';' && i < line.size()) {
			command1 += line[i];
			++i;
		}

		//Register check
		if ((command1[0] == 'R' || command1[0] == 'r')) {
			if (-1 != command1.find_first_not_of("Rr12345,"))
				return 0;
		}//Memory Address check 
		else if ((command1[0] == '#')) {
			if (-1 != command1.find_first_not_of("#1234567890,")) {
				return 0;
			}
		}//Constant check
		else if (('1' <= command1[0] <= '9') || (command1[0] == '-')) {

			if (-1 != command1.find_first_not_of("1234567890-"))
				return 0;
		}//Invalid Input
		else {
			return 0;
		}
		if (command1.size() >= 1)
			read++;
	}

	//Whitespace'ler atlanir
	while (line[i] == ' ' || line[i] == '\t') {
		i++;
		if (i == line.size())
			break;
	}

	// Eger varsa line icindeki 3. string alinarak command2'e doldurulur, geçerli bir input olup olmadigi kontrol edilir.
	//Hatali ise 0 return edilir.
	if (i < line.size()) {
		while (line[i] != ' ' && line[i] != '\t' && line[i] != ';' && i < line.size()) {
			command2 += line[i];
			++i;
		}
		//Register Check
		if ((command2[0] == 'R' || command2[0] == 'r')) {
			if (-1 != command2.find_first_not_of("Rr12345"))
				return 0;
		}//Memory Address check 
		else if ((command2[0] == '#')) {
			if (-1 != command2.find_first_not_of("#1234567890")) {
				return 0;
			}
		}//Constant check
		else if (('1' <= command2[0] <= '9') || (command2[0] == '-')) {

			if (-1 != command2.find_first_not_of("1234567890-"))
				return 0;
		}//Invalid Input
		else {
			return 0;
		}

		if (command2.size() >= 1)
			read++;
	}

	return read;
}

//Integer'dan olusan stringleri integer olarak return eden func.
// option -> 0 for constant
// option -> 1 for Memory

int HandMadeAtoi(string strLine, int option) {
	int integerValue = 0;

	if (option == 0) {
		if (strLine[0] == '-') {
			for (int i = 1; i < strLine.size(); ++i) {
				integerValue += ((int)(strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
			}
			integerValue *= -1;
		}
		else
			for (int i = 0; i < strLine.size(); ++i) {
				integerValue += ((int)(strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
			}
	}
	else {
		if (strLine[strLine.size() - 1] == ',') {
			for (int i = 1; i < (strLine.size() - 1); ++i) {
				integerValue += ((int)(strLine[i] - '0')) * pow(10, strLine.size() - i - 2);
			}
		}
		else {
			for (int i = 1; i < strLine.size(); ++i) {
				integerValue += ((int)(strLine[i] - '0')) * pow(10, strLine.size() - i - 1);
			}
		}
	}

	return integerValue;
}
