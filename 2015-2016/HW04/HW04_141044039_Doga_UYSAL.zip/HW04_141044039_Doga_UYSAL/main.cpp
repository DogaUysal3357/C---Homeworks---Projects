/* 
 * File:   main.cpp
 * Author: Doğa
 *
 * Created on 08 Kasım 2015 Pazar, 16:15
 */


#include <cstdlib>
#include <iostream>
#include "Cell.h"
#include "Reversi.h"

using namespace std;


/*
 * 
 */
int main(int argc, char** argv) {

    Reversi game;
    
    game.playGame();
    
    
    return 0;
}

