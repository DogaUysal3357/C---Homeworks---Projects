/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044039_doğa_uysal;

/**
 *
 * @author Doğa UYSAL
 * No : 141044039
 */
public class arithmeticexpressions {

    
    public static void main(String[] args) {
       
        Expressions test = new Expressions();
        
        test.takeExpressionAndCalculate();
        
    }
    
}
