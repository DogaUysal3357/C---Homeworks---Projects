/* 
 * File:   ImaginaryNumber.h
 * Author: Doğa
 *
 * Created on 16 Aralık 2015 Çarşamba, 00:55
 */

#ifndef IMAGINARYNUMBER_H
#define	IMAGINARYNUMBER_H

#include "ComplexNumber.h"

namespace Numbers_Doga {

    class ImaginaryNumber : public ComplexNumber {
    public:
        ImaginaryNumber();
        ImaginaryNumber(char _s, int _y1, int _y2);
        ImaginaryNumber(char _s, int _x1, int _x2, int _y1, int _y2);

        friend ostream& operator<<(ostream& outStream, ImaginaryNumber & printed);

        void printFormat()const;
        void setNumber();

        void setReal(int _x1, int _x2);
    };
}
#endif	/* IMAGINARYNUMBER_H */
