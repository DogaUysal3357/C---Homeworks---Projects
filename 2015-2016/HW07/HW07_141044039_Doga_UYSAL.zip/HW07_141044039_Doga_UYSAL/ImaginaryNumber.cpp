/* 
 * File:   ImaginaryNumber.cpp
 * Author: Doğa
 * 
 * Created on 16 Aralık 2015 Çarşamba, 00:55
 */

#include "ImaginaryNumber.h"

namespace Numbers_Doga {

    ImaginaryNumber::ImaginaryNumber() : ComplexNumber('+', 0, 1, 1, 1) {

    }

    ImaginaryNumber::ImaginaryNumber(char _s, int _y1, int _y2) : ComplexNumber(_s, 0, 1, _y1, _y2) {

    }

    ImaginaryNumber::ImaginaryNumber(char _s, int _x1, int _x2, int _y1, int _y2) : ComplexNumber(_s, _x1, _x2, _y1, _y2) {
        setReal(_x1, _x2);
    }

    void ImaginaryNumber::setReal(int _x1, int _x2) {
        if (_x1 != 0) {
            cerr << "Gecerli bir ImaginaryNumber girmediniz." << endl;
            exit(1);
        } else {
            setReal1(_x1);
            setReal2(_x2);
        }

    }

    void ImaginaryNumber::printFormat() const {
        cout << "ImaginaryNumber uzerinde islem yapmak uzeresiniz." << endl
                << "Input girislerinizi integer olarak ve" << endl
                << "Imaginary Part1 ve Imaginary Part2 olmak uzere yapınız" << endl
                << " ORN: (Img 1 / Img 2)*i" << endl;
    }

    void ImaginaryNumber::setNumber() {

        int temp;
        char tempC = '+';


        cout << "Sayiniz isaretini giriniz (+/-):";
        while (tempC != '+' || tempC != '-') {
            cin >> tempC;
            cout << endl;
            if (tempC != '+' || tempC != '-') {
                cout << "Gecerli bir karakter girmediniz. Tekrar deneyiniz :";
            }
        }

        cout << "Imaginary Part1 giriniz : ";
        cin >> temp;
        setImg1(temp);
        cout << endl;

        cout << "Imaginary Part2 giriniz : ";
        cin >> temp;
        setImg2(temp);
        cout << endl;

    }

    ostream& operator<<(ostream& outStream, ImaginaryNumber & printed) {
        outStream << "ImaginaryNumber'iniz : " << endl

                << "( " << printed.getImg1() << " / " << printed.getImg2() << " )i  = "

                << " ( " << printed.getImg1() / printed.getImg2() << " )i"

                << endl << endl;
        return outStream;
    }
}