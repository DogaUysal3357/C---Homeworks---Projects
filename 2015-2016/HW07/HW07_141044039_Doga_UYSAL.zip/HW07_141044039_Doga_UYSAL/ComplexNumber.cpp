/* 
 * File:   ComplexNumber.cpp
 * Author: Doğa
 * 
 * Created on 15 Aralık 2015 Salı, 16:55
 */

#include <cmath>

#include "ComplexNumber.h"

namespace Numbers_Doga {

    ComplexNumber::ComplexNumber() {
        setSign('+');
        setReal(1, 1);
        setImg(1, 1);
    }

    ComplexNumber::ComplexNumber(char _s, int _x1, int _x2) {
        setSign(_s);
        setImg(0, 1);
        setReal(_x1, _x2);
    }

    ComplexNumber::ComplexNumber(char _s, int _x1, int _x2, int _y1, int _y2) {
        setSign(_s);
        setImg(_y1, _y2);
        setReal(_x1, _x2);
    }

    // setter ve getter'lar

    int ComplexNumber::getReal1() const {
        return real1;
    }

    void ComplexNumber::setReal1(int _x) {
        real1 = _x;
    }

    int ComplexNumber::getReal2() const {
        return real2;
    }

    void ComplexNumber::setReal2(int _x) {
        real2 = _x;
    }

    int ComplexNumber::getImg1() const {
        return img1;
    }

    void ComplexNumber::setImg1(int _x) {
        img1 = _x;
    }

    int ComplexNumber::getImg2() const {
        return img2;
    }

    void ComplexNumber::setImg2(int _x) {
        img2 = _x;
    }

    char ComplexNumber::getSign() const {
        return sign;
    }

    void ComplexNumber::setSign(char _c) {
        sign = _c;
    }

    void ComplexNumber::setImg(int _y1, int _y2) {
        setImg1(_y1);
        setImg2(_y2);
    }

    void ComplexNumber::setReal(int _x1, int _x2) {
        setReal1(_x1);
        setReal2(_x2);
    }

    void ComplexNumber::printFormat() const {

        cout << "ComplexNumber uzerinde islem yapmak uzeresiniz." << endl
                << "Input girislerinizi integer olarak ve" << endl
                << "Real part1, Real part2, Imaginary Part1 ve Imaginary Part2 olmak uzere yapınız" << endl
                << " ORN: (Real 1 / Real 2) + (Img 1 / Img 2)*i" << endl;
    }

    /* NOT: girilen sayiyi ekrana basabilirsin   */
    void ComplexNumber::setNumber() {

        int temp;
        char tempC = '+';


        cout << "Sayiniz isaretini giriniz (+/-):";
        while (tempC != '+' || tempC != '-') {
            cin >> tempC;
            cout << endl;
            if (tempC != '+' || tempC != '-') {
                cout << "Gecerli bir karakter girmediniz. Tekrar deneyiniz :";
            }
        }

        cout << "Real part1 giriniz : ";
        cin >> temp;
        setReal1(temp);
        cout << endl;

        cout << "Real part2 giriniz : ";
        cin >> temp;
        setReal2(temp);
        cout << endl;

        cout << "Imaginary Part1 giriniz : ";
        cin >> temp;
        setImg1(temp);
        cout << endl;

        cout << "Imaginary Part2 giriniz : ";
        cin >> temp;
        setImg2(temp);
        cout << endl;
    }

    ComplexNumber ComplexNumber::operator+(ComplexNumber & add) {
        int x1, x2, y1, y2;

        if (getSign() == '+' && add.getSign() == '+') {
            x1 = (getReal1() * add.getReal2()) + (add.getReal1() * getReal2());
            x2 = (getReal2() * add.getReal2());

            y1 = (getImg1() * add.getImg2()) + (add.getImg1() * getImg2());
            x2 = (getImg2() * add.getImg2());
        }

        if (getSign() == '-' && add.getSign() == '-') {
            x1 = ((-getReal1()) * add.getReal2()) + ((-add.getReal1()) * getReal2());
            x2 = (getReal2() * add.getReal2());

            y1 = ((-getImg1()) * add.getImg2()) + ((-add.getImg1()) * getImg2());
            x2 = (getImg2() * add.getImg2());

        } else if (getSign() == '-' || add.getSign() == '-') {
            x1 = ((-getReal1()) * add.getReal2()) + (add.getReal1() * getReal2());
            x2 = (getReal2() * add.getReal2());

            y1 = ((-getImg1()) * add.getImg2()) + (add.getImg1() * getImg2());
            x2 = (getImg2() * add.getImg2());
        }


        ComplexNumber result('+', x1, x2, y1, y2);

        return result;
    }

    ComplexNumber ComplexNumber::operator-(ComplexNumber & minus) {
        int x1, x2, y1, y2;

        if (getSign() == '+' && minus.getSign() == '+') {
            x1 = (getReal1() * minus.getReal2()) - (minus.getReal1() * getReal2());
            x2 = (getReal2() * minus.getReal2());

            y1 = (getImg1() * minus.getImg2()) - (minus.getImg1() * getImg2());
            x2 = (getImg2() * minus.getImg2());
        }

        if (getSign() == '-' && minus.getSign() == '-') {
            x1 = ((-getReal1()) * minus.getReal2()) - ((-minus.getReal1()) * getReal2());
            x2 = (getReal2() * minus.getReal2());

            y1 = ((-getImg1()) * minus.getImg2()) - ((-minus.getImg1()) * getImg2());
            x2 = (getImg2() * minus.getImg2());

        } else if (getSign() == '-' || minus.getSign() == '-') {
            x1 = ((-getReal1()) * minus.getReal2()) - (minus.getReal1() * getReal2());
            x2 = (getReal2() * minus.getReal2());

            y1 = ((-getImg1()) * minus.getImg2()) - (minus.getImg1() * getImg2());
            x2 = (getImg2() * minus.getImg2());
        }


        ComplexNumber result('+', x1, x2, y1, y2);

        return result;

    }

    const bool ComplexNumber::operator<(ComplexNumber & compared) {

        double first = sqrt(((compared.getReal1() * compared.getReal1()) / (compared.getReal2() * compared.getReal2())) + ((compared.getImg1() * compared.getImg1()) / compared.getImg2() * compared.getImg2()));
        double second = sqrt(((compared.getReal1() * compared.getReal1()) / (compared.getReal2() * compared.getReal2())) + ((compared.getImg1() * compared.getImg1()) / compared.getImg2() * compared.getImg2()));

        return first < second;
    }

    ostream& operator<<(ostream& outStream, const ComplexNumber & printed) {

        outStream << "ComplexNumber'iniz : " << endl

                << printed.getSign() << "( " << printed.getReal1() << " / " << printed.getReal2() << " ) + "
                << "( " << printed.getImg1() << " / " << printed.getImg2() << " )i  = "

                << printed.getSign() << "( " << printed.getReal1() / printed.getReal2() << " ) + "
                << " ( " << printed.getImg1() / printed.getImg2() << " )i"

                << endl << endl;
        return outStream;
    }
}