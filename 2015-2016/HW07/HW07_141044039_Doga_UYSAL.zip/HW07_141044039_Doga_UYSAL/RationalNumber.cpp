/* 
 * File:   RationalNumber.cpp
 * Author: Doğa
 * 
 * Created on 16 Aralık 2015 Çarşamba, 01:58
 */

#include "RationalNumber.h"
namespace Numbers_Doga {

    RationalNumber::RationalNumber() : RealNumber() {

    }

    RationalNumber::RationalNumber(char _s, int _x1, int _x2) : RealNumber(_s, _x1, _x2) {

    }

    RationalNumber::RationalNumber(char _s, int _x1, int _x2, int _y1, int _y2) : RealNumber(_s, _x1, _x2, _y1, _y2) {
        setImg(_y1, _y2);
    }

    void RationalNumber::setImg(int _y1, int _y2) {
        if (_y1 != 0) {
            cerr << "Gecerli bir RationalNumber girmediniz." << endl;
            exit(1);
        } else {
            setImg1(_y1);
            setImg2(_y2);
        }
    }

    void RationalNumber::printFormat() const {

        cout << "RationalNumber uzerinde islem yapmak uzeresiniz." << endl
                << "Input girislerinizi integer olarak ve" << endl
                << "Rational part1, Rational part2 olmak uzere yapınız" << endl
                << " ORN: (Rational 1 / Rational 2)" << endl;
    }

    /* NOT: girilen sayiyi ekrana basabilirsin*/
    void RationalNumber::setNumber() {

        int temp;
        char tempC = '+';


        cout << "Sayiniz isaretini giriniz (+/-):";
        while (tempC != '+' || tempC != '-') {
            cin >> tempC;
            cout << endl;
            if (tempC != '+' || tempC != '-') {
                cout << "Gecerli bir karakter girmediniz. Tekrar deneyiniz :";
            }
        }

        cout << "Rational part1 giriniz : ";
        cin >> temp;
        setReal1(temp);
        cout << endl;

        cout << "Rational part2 giriniz : ";
        cin >> temp;
        setReal2(temp);
        cout << endl;


    }

    ostream& operator<<(ostream& outStream, RationalNumber & printed) {

        outStream << "RationalNumber'iniz : " << endl

                << printed.getSign() << "( " << printed.getReal1() << " / " << printed.getReal2() << " ) = "

                << printed.getSign() << "( " << printed.getReal1() / printed.getReal2() << " ) "

                << endl << endl;
        return outStream;
    }
}