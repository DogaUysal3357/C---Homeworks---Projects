/* 
 * File:   RationalNumber.h
 * Author: Doğa
 *
 * Created on 16 Aralık 2015 Çarşamba, 01:58
 */

#ifndef RATIONALNUMBER_H
#define	RATIONALNUMBER_H

#include "RealNumber.h"
namespace Numbers_Doga {

    class RationalNumber : public RealNumber {
    public:
        RationalNumber();
        RationalNumber(char _s, int _y1, int _y2);
        RationalNumber(char _s, int _x1, int _x2, int _y1, int _y2);

        friend ostream& operator<<(ostream& outStream, RationalNumber & printed);

        void printFormat()const;
        void setNumber();

        void setImg(int _y1, int _y2);
    };
}
#endif	/* RATIONALNUMBER_H */
