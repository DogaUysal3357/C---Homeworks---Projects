/* 
 * File:   IntegerNumber.cpp
 * Author: Doğa
 * 
 * Created on 16 Aralık 2015 Çarşamba, 02:12
 */

#include "IntegerNumber.h"
namespace Numbers_Doga {

    IntegerNumber::IntegerNumber() : RationalNumber() {

    }

    IntegerNumber::IntegerNumber(char _s, int _x1, int _x2) : RationalNumber(_s, _x1, 1) {

    }

    IntegerNumber::IntegerNumber(char _s, int _x1, int _x2, int _y1, int _y2) : RationalNumber( _s, _x1, _x2, _y1,  _y2) {
        setReal(_x1, _x2);
    }

    void IntegerNumber::setReal(int _x1, int _x2) {
        if (_x2 != 1) {
            cerr << "Gecerli bir IntegerNumber girmediniz." << endl;
            exit(1);
        } else {
            setReal1(_x1);
            setReal2(_x2);
        }
    }

    void IntegerNumber::printFormat() const {

        cout << "IntegerNumber uzerinde islem yapmak uzeresiniz." << endl
                << "Input girislerinizi integer olarak ve" << endl
                << "Integer kisim olmak uzere yapınız" << endl
                << " ORN: Integer" << endl;
    }

    void IntegerNumber::setNumber() {

        int temp;
        char tempC = '+';


        cout << "Sayiniz isaretini giriniz (+/-):";
        while (tempC != '+' || tempC != '-') {
            cin >> tempC;
            cout << endl;
            if (tempC != '+' || tempC != '-') {
                cout << "Gecerli bir karakter girmediniz. Tekrar deneyiniz :";
            }
        }

        cout << "Integer giriniz : ";
        cin >> temp;
        setReal(temp, 1);
        cout << endl;

    }

    ostream& operator<<(ostream& outStream, IntegerNumber & printed) {

        outStream << "IntegerNumber'iniz : " << endl

                << printed.getSign() << "( " << printed.getReal1() << " ) "
                << endl << endl;

        return outStream;
    }

}