/* 
 * File:   RealNumber.h
 * Author: Doğa
 *
 * Created on 16 Aralık 2015 Çarşamba, 01:52
 */

#ifndef REALNUMBER_H
#define	REALNUMBER_H

#include "ComplexNumber.h"

namespace Numbers_Doga {

    class RealNumber : public ComplexNumber {
    public:
        RealNumber();
        RealNumber(char _s, int _y1, int _y2);
        RealNumber(char _s, int _x1, int _x2, int _y1, int _y2);

        friend ostream& operator<<(ostream& outStream, RealNumber & printed);

        void printFormat()const;
        void setNumber();

        void setImg(int _y1, int _y2);
    };
}
#endif	/* REALNUMBER_H */
