/* 
 * File:   NaturalNumber.h
 * Author: Doğa
 *
 * Created on 16 Aralık 2015 Çarşamba, 02:12
 */

#ifndef NATURALNUMBER_H
#define	NATURALNUMBER_H

#include "IntegerNumber.h"

namespace Numbers_Doga {

    class NaturalNumber : public IntegerNumber {
    public:
        NaturalNumber();
        NaturalNumber(char _s, int _x1, int _x2);
        NaturalNumber(char _s, int _x1, int _x2, int _y1, int _y2);

        friend ostream& operator<<(ostream& outStream, NaturalNumber & printed);

        void printFormat()const;
        void setNumber();

        void setReal(int _x1, int _x2);
    };
}
#endif	/* NATURALNUMBER_H */
