/* 
 * File:   main.cpp
 * Author: Doğa
 *
 * Created on 15 Aralık 2015 Salı, 16:54
 */

#include <cstdlib>
#include <stdlib.h>
#include "ComplexNumber.h"
#include "IntegerNumber.h"
#include "ImaginaryNumber.h"
#include "NaturalNumber.h"
#include "RealNumber.h"
#include "RationalNumber.h"

using namespace Numbers_Doga;

int main(int argc, char** argv) {

    ComplexNumber first;
    IntegerNumber second;
    RationalNumber third;



    cout << (second + third);
    cout << (first - second);
    
    first.printFormat();
    first.setNumber();
    
    second.printFormat();
    second.setNumber();
    
    third.printFormat();
    third.setNumber();
    
    cout << (second + third);
    cout << (first - second);

    return 0;
}
