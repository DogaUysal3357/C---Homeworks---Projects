/* 
 * File:   ComplexNumber.h
 * Author: Doğa
 *
 * Created on 15 Aralık 2015 Salı, 16:55
 */

#ifndef COMPLEXNUMBER_H
#define	COMPLEXNUMBER_H
#include <math.h>
#include <iostream>
#include <stdlib.h>



using namespace std;

namespace Numbers_Doga {

    class ComplexNumber {
    public:
        ComplexNumber();
        ComplexNumber(char _s, int _x1, int _x2);
        ComplexNumber(char _s, int _x1, int _x2, int _y1, int _y2);

        virtual ComplexNumber operator+(ComplexNumber & add);
        virtual ComplexNumber operator-(ComplexNumber & minus);
        virtual const bool operator<(ComplexNumber & compared);
        friend ostream& operator<<(ostream& outStream, const ComplexNumber & printed);


        //Kullanici icin kullanilan sayinin formatini ekrana basar
        void printFormat()const;
        //  Kullanicidan input alarak sayiyi degistirir.
        void setNumber();

        //getters setters
        int getReal1() const;
        void setReal1(int _x);

        int getReal2() const;
        void setReal2(int _x);

        int getImg1() const;
        void setImg1(int _x);

        int getImg2() const;
        void setImg2(int _x);

        void setReal(int _x1, int _x2); // Real kisimlari birlikte degistirir
        void setImg(int _y1, int _y2); // Imaginary kisimlari birlikte degistirir.

        char getSign() const;
        void setSign(char _c);

    private:
        char sign; // Sayinin isareti
        int real1; // Real kisimin boluneni
        int real2; // Real kisimin boleni
        int img1; // Imaginary kisimin boluneni
        int img2; // Imaginary kisimin boleni
    };
}
#endif	/* COMPLEXNUMBER_H */
