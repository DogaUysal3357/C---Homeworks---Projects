/* 
 * File:   NaturalNumber.cpp
 * Author: Doğa
 * 
 * Created on 16 Aralık 2015 Çarşamba, 02:12
 */

#include "NaturalNumber.h"

namespace Numbers_Doga {

    NaturalNumber::NaturalNumber() : IntegerNumber() {

    }

    NaturalNumber::NaturalNumber(char _s, int _x1, int _x2) : IntegerNumber(_s, _x1, 1) {

    }

    NaturalNumber::NaturalNumber(char _s, int _x1, int _x2, int _y1, int _y2) : IntegerNumber(_s,  _x1, _x2, _y1, _y2) {
        setReal(_x1, _x2);
    }

    void NaturalNumber::setReal(int _x1, int _x2) {
        if (_x1 < 1) {
            cerr << "Gecerli bir NaturalNumber girmediniz." << endl;
            exit(1);
        }
    }

    void NaturalNumber::printFormat() const {

        cout << "NaturalNumber uzerinde islem yapmak uzeresiniz." << endl
                << "Input girislerinizi integer olarak ve" << endl
                << "Integer kisim olmak uzere yapınız ve sifirdan buyuk bir rakam giriniz." << endl
                << " ORN: Integer" << endl;
    }

    /* NOT: girilen sayiyi ekrana basabilirsin*/
    void NaturalNumber::setNumber() {

        int temp;

        cout << "Sifirdan buyuk bir integer giriniz : ";
        cin >> temp;
        setReal(temp, 1);
        cout << endl;

    }

    ostream& operator<<(ostream& outStream, NaturalNumber & printed) {

        outStream << "NaturalNumber'iniz : " << endl

                << printed.getSign() << "( " << printed.getReal1()
                << endl << endl;

        return outStream;
    }
}