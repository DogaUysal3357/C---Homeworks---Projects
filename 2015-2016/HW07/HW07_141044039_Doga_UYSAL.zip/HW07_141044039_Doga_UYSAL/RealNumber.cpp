/* 
 * File:   RealNumber.cpp
 * Author: Doğa
 * 
 * Created on 16 Aralık 2015 Çarşamba, 01:52
 */

#include "RealNumber.h"

namespace Numbers_Doga {

    RealNumber::RealNumber() : ComplexNumber('+', 1, 1, 0, 1) {

    }

    RealNumber::RealNumber(char _s, int _x1, int _x2) : ComplexNumber(_s, _x1, _x2, 0, 1) {

    }

    RealNumber::RealNumber(char _s, int _x1, int _x2, int _y1, int _y2) : ComplexNumber(_s, _x1, _x2, _y1, _y2) {
        setImg(_y1, _y2);
    }

    void RealNumber::setImg(int _y1, int _y2) {
        if (_y1 != 0) {
            cerr << "Gecerli bir RealNumber girmediniz." << endl;
            exit(1);
        } else {
            setImg1(_y1);
            setImg2(_y2);
        }
    }

    void RealNumber::printFormat() const {

        cout << "RealNumber uzerinde islem yapmak uzeresiniz." << endl
                << "Input girislerinizi integer olarak ve" << endl
                << "Real part1, Real part2 olmak uzere yapınız" << endl
                << " ORN: (Real 1 / Real 2)" << endl;
    }

    /* NOT: girilen sayiyi ekrana basabilirsin*/
    void RealNumber::setNumber() {

        int temp;
        char tempC = '+';


        cout << "Sayiniz isaretini giriniz (+/-):";
        while (tempC != '+' || tempC != '-') {
            cin >> tempC;
            cout << endl;
            if (tempC != '+' || tempC != '-') {
                cout << "Gecerli bir karakter girmediniz. Tekrar deneyiniz :";
            }
        }

        cout << "Real part1 giriniz : ";
        cin >> temp;
        setReal1(temp);
        cout << endl;

        cout << "Real part2 giriniz : ";
        cin >> temp;
        setReal2(temp);
        cout << endl;


    }

    ostream& operator<<(ostream& outStream, RealNumber & printed) {

        outStream << "RealNumber'iniz : " << endl

                << printed.getSign() << "( " << printed.getReal1() << " / " << printed.getReal2() << " ) = "

                << printed.getSign() << "( " << printed.getReal1() / printed.getReal2() << " ) "

                << endl << endl;
        return outStream;
    }
}